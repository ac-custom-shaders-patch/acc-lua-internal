Sources:
https://www.xda-developers.com/android-auto-5-8-prepares-to-let-you-change-the-wallpaper-and-tests-google-assistant-shortcuts/
https://9to5google.com/2021/01/13/android-auto-moves-closer-to-wallpaper-support-w-collection-of-car-themed-backgrounds/
